/*
 * PROYEK AKHIR: SISTEM PENGUNCI PINTU OTOMATIS (RFID + BLYNK)
 * Dibuat untuk Simulasi Wokwi menggunakan ESP32
 */

// --- 1. CONFIG BLYNK (Menggunakan Kredensial Aktif Anda) ---
#define BLYNK_TEMPLATE_ID "TMPLGbBiYvjVj"
#define BLYNK_TEMPLATE_NAME "Smart Door Lock"
#define BLYNK_AUTH_TOKEN "FXpRfIcR2mBD2DeXbK_nzyyjArhwZnf8"

#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- 2. PIN DEFINITIONS ---
#define SS_PIN    5   // RFID SDA
#define RST_PIN   14  // RFID Reset (Diubah ke 14 untuk menghindari konflik dengan I2C SCL GPIO 22)
#define SERVO_PIN 13  // Servo Motor Signal
#define BUZZER    12  // Buzzer Signal
#define LED_GREEN 2   // LED Hijau (Akses Diterima)
#define LED_RED   4   // LED Merah (Akses Ditolak)

// --- 3. HARDWARE INSTANCES ---
MFRC522 rfid(SS_PIN, RST_PIN);
Servo kunciPintu;
LiquidCrystal_I2C lcd(0x27, 16, 2);

// --- 4. DATA DEKLARASI ---
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST"; // Default WiFi untuk Wokwi Simulator
char pass[] = "";            // Wokwi tidak membutuhkan password

// UID Kartu RFID yang Terdaftar (Contoh: Kartu Hijau di Wokwi "11 22 33 44")
//String authorizedUID = "01 02 03 04"; 

// UID Kartu RFID yang Salah
String authorizedUID = "11 22 33 44";

bool statusKunci = true; // true = Terkunci, false = Terbuka

// --- 5. BLYNK WRITE (Menerima Perintah dari Aplikasi Blynk) ---
BLYNK_WRITE(V0) {
  int pinValue = param.asInt(); // Mendapatkan nilai 0 atau 1 dari tombol Blynk
  
  if (pinValue == 1) {
    bukaPintu("Akses Jarak Jauh");
  } else {
    kunciPintuOtomatis("Akses Jarak Jauh");
  }
}

// --- 6. FUNGSI UTAMA BUKA PINTU ---
void bukaPintu(String sumberAkses) {
  statusKunci = false;
  kunciPintu.write(90); // Putar servo 90 derajat (Kunci Terbuka)
  
  // LED & Buzzer Feedback
  digitalWrite(LED_GREEN, HIGH);
  digitalWrite(LED_RED, LOW);
  
  // Bunyi Buzzer Pendek (Indikasi Sukses)
  digitalWrite(BUZZER, HIGH);
  delay(150);
  digitalWrite(BUZZER, LOW);
  
  // Tampilan LCD
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("AKSES DITERIMA!");
  lcd.setCursor(0, 1);
  lcd.print("Pintu Terbuka");
  
  // Kirim data status ke Blynk App
  Blynk.virtualWrite(V1, "Terbuka oleh: " + sumberAkses);
  Blynk.virtualWrite(V0, 1); // Sinkronkan tombol di aplikasi Blynk
  
  Serial.println("Pintu Terbuka oleh " + sumberAkses);
}

// --- 7. FUNGSI UTAMA KUNCI PINTU ---
void kunciPintuOtomatis(String sumberAkses) {
  statusKunci = true;
  kunciPintu.write(0); // Kembalikan servo ke 0 derajat (Kunci Tertutup)
  
  // LED Feedback
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_RED, HIGH);
  
  // Tampilan LCD Standby
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("PINTU TERKUNCI");
  lcd.setCursor(0, 1);
  lcd.print("Scan Kartu Anda");
  
  // Kirim data status ke Blynk App
  Blynk.virtualWrite(V1, "Pintu Terkunci (" + sumberAkses + ")");
  Blynk.virtualWrite(V0, 0); // Sinkronkan tombol di aplikasi Blynk
  
  Serial.println("Pintu Terkunci oleh " + sumberAkses);
}

// --- 8. FUNGSI AKSES DITOLAK (Salah Kartu) ---
void aksesDitolak() {
  digitalWrite(LED_RED, HIGH);
  digitalWrite(LED_GREEN, LOW);
  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("AKSES DITOLAK!");
  lcd.setCursor(0, 1);
  lcd.print("Kartu Tak Dikenal");
  
  // Alarm Peringatan Buzzer Bip Cepat 3 Kali
  for (int i = 0; i < 3; i++) {
    digitalWrite(BUZZER, HIGH);
    delay(100);
    digitalWrite(BUZZER, LOW);
    delay(100);
  }
  
  // Kirim Log Peringatan ke Blynk App
  Blynk.virtualWrite(V1, "PERINGATAN: Upaya Akses Ilegal Dideteksi!");
  Blynk.logEvent("akses_ilegal", "Seseorang mencoba membuka pintu dengan kartu tidak dikenal!"); // Opsional jika event dibuat di Blynk
  
  delay(1000);
  
  // Kembalikan ke Tampilan Standby
  if (statusKunci) {
    kunciPintuOtomatis("Sistem");
  } else {
    bukaPintu("Sistem");
  }
}

// --- 9. ARDUINO SETUP ---
void setup() {
  Serial.begin(115200);
  
  // Pin Modes
  pinMode(BUZZER, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  
  // Inisialisasi LED awal (Kondisi Terkunci)
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_RED, HIGH);
  
  // Inisialisasi LCD
  Wire.begin(21, 22); // Gunakan PIN I2C standard ESP32 (SDA: 21, SCL: 22)
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Connecting WiFi...");
  
  // Inisialisasi Blynk & Koneksi WiFi
  Blynk.begin(auth, ssid, pass);
  
  // Inisialisasi Hardware RFID & Servo
  SPI.begin();
  rfid.PCD_Init();
  kunciPintu.attach(SERVO_PIN);
  
  // Set Kondisi Awal Terkunci
  kunciPintuOtomatis("Sistem");
}

// --- 10. ARDUINO LOOP ---
void loop() {
  Blynk.run(); // Menjalankan proses Blynk IoT
  
  // Cek apakah ada kartu RFID baru yang didekatkan ke sensor
  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }
  
  // Membaca ID dari kartu tersebut
  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }
  
  // Mengonversi UID Kartu menjadi format String (HEX)
  String scannedUID = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    scannedUID.concat(String(rfid.uid.uidByte[i] < 0x10 ? " 0" : " "));
    scannedUID.concat(String(rfid.uid.uidByte[i], HEX));
  }
  scannedUID.trim();
  scannedUID.toUpperCase();
  
  Serial.print("Kartu Ter-scan, UID: ");
  Serial.println(scannedUID);
  
  // Proses Verifikasi Kartu
  if (scannedUID == authorizedUID) {
    // Jika pintu sedang terkunci, maka buka. Jika pintu terbuka, kunci kembali (Toggle mode)
    if (statusKunci) {
      bukaPintu("Kartu RFID Terdaftar");
    } else {
      kunciPintuOtomatis("Kartu RFID Terdaftar");
    }
  } else {
    aksesDitolak();
  }
  
  // Hentikan enkripsi kartu pasif untuk menghindari looping scan
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
